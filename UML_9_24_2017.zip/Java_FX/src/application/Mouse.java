package application;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Mouse extends Application {

    class DragContext {
        double x;
        double y;
    }

    DragContext dragContext = new DragContext();

    public void makeDraggable( Node node) {
        node.setOnMousePressed( onMousePressedEventHandler);
        node.setOnMouseDragged( onMouseDraggedEventHandler);
        node.setOnMouseReleased(onMouseReleasedEventHandler);
    }

    EventHandler<MouseEvent> onMousePressedEventHandler = new EventHandler<MouseEvent>() {

        @Override
        public void handle(MouseEvent event) {

            if( event.getSource() instanceof Circle) {

                Circle circle = ((Circle) (event.getSource()));

                dragContext.x = circle.getCenterX() - event.getSceneX();
                dragContext.y = circle.getCenterY() - event.getSceneY();

            } else {

                Node node = ((Node) (event.getSource()));

                dragContext.x = node.getTranslateX() - event.getSceneX();
                dragContext.y = node.getTranslateY() - event.getSceneY();

            }
        }
    };

    EventHandler<MouseEvent> onMouseDraggedEventHandler = new EventHandler<MouseEvent>() {

        @Override
        public void handle(MouseEvent event) {

            if( event.getSource() instanceof Circle) {

                Circle circle = ((Circle) (event.getSource()));

                circle.setCenterX( dragContext.x + event.getSceneX());
                circle.setCenterY( dragContext.y + event.getSceneY());

            } else {

                Node node = ((Node) (event.getSource()));

                node.setTranslateX( dragContext.x + event.getSceneX());
                node.setTranslateY( dragContext.y + event.getSceneY());

            }

        }
    };

    EventHandler<MouseEvent> onMouseReleasedEventHandler = new EventHandler<MouseEvent>() {

        @Override
        public void handle(MouseEvent event) {

        }
    };



	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
