package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class CreateLine 
{
	
	double orgSceneX, orgSceneY;
	
	/**
	 * 
	 * @param pane (Pane)
	 * @param frameX (Double)
	 * @param frameY (Double)
	 * Creates a new line that is able to be moved and resized
	 * @returns an newly created Line Button 
	 * 			
	 */

	public Button display(Pane pane, Double frameX, Double frameY) 
	{
		Button line = new Button("Line");
		
		//Button listener to create a new line
		line.setOnAction(new EventHandler<ActionEvent>()
		{
		       @Override
		       public void handle(ActionEvent e) 
		       {
		    	   
		    	   	//creates new Ball by passing frameX, frameY and the radius 
		    		Ball c1 = new Ball(frameX, frameY, 10);
		    	   	c1.setFill(Color.TRANSPARENT);
		    	   	pane.getChildren().addAll(c1);
		    	   	
		    	   	//creates new Ball by passing frameX, frameY and the radius
		    	   	Ball c2 = new Ball(frameX + 5, frameY + 5, 10);
		    	   	c2.setFill(Color.BLACK);
		    	   	pane.getChildren().addAll(c2);
		    	   	
		    	   	//create new Connection by passing c1(Ball) and c2(Ball) 
			    	Connection connection = new Connection(c1, c2);
			    	pane.getChildren().addAll(connection);
		       }	
		       
		});
		
		return line;
	}
}
