package application;

import javafx.geometry.Insets;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseButton;

public class createTextBox 
{

	double orgSceneX, orgSceneY;
	
	/*
	 * 
	 * @param frameX (Double)
	 * @param frameY (Double)
	 * Creates a text box that is able to drag around the screen
	 * @returns an HBox consisting of a text box
	 * 			
	 */
	
	public HBox display(Double frameX, Double frameY)
	{
		HBox group = new HBox();
		TextArea text1 = new TextArea();
		text1.setPrefHeight(20);
		text1.setPrefWidth(100);
		text1.setText("Enter Text");
		text1.setWrapText(true);
		group.setLayoutX(frameX);
		group.setLayoutY(frameY);
		group.setBorder(null);
		group.setPadding(new Insets(5, 5, 5, 5));
		group.setBackground(new Background(new BackgroundFill(Color.web("#C0C0C0"), CornerRadii.EMPTY, Insets.EMPTY)));
		group.getChildren().addAll(text1);
		
		group.setOnMousePressed((t) -> 
	    {
	      orgSceneX = t.getSceneX();
	      orgSceneY = t.getSceneY();
	      
	      // rotates if left mouse button clicks on it
	      MouseButton b = t.getButton();
	      if(b == MouseButton.PRIMARY && t.isStillSincePress()) {
	      group.setRotate(group.getRotate() + 15);
	      }
	      HBox g = (HBox) (t.getSource());
	      g.toFront();
	    });
		 group.setOnMouseDragged((t) -> 
		    {
		        double offsetX = t.getSceneX() - orgSceneX;
		        double offsetY = t.getSceneY() - orgSceneY;
			      MouseButton b = t.getButton();
			      
			  // resizes if right mouse button is held down and dragged
		      if(b == MouseButton.SECONDARY) {
		      double temp = offsetX / 100.0;
		      
		      double temp2 = offsetY / 100.0;
		      
		      if(temp < 0.0)
		      {
		      group.setScaleX(group.getScaleX() + (temp / 100.0) - 0.02);
		      }
		      if(temp2 < 0.0)
		      {
		      group.setScaleY(group.getScaleY() + (temp2 / 100.0) - 0.02);
		      }
		      if(temp > 0.0)
		      {
		      group.setScaleX(group.getScaleX() + (temp / 100.0) + 0.02);
		      }
		      if(temp2 > 0.0)
		      {
		      group.setScaleY(group.getScaleY() + (temp2 / 100.0) + 0.02); 
		      }
		   
		      }
		      
		      // moves it if anything but right mouse button is held
		      if(b != MouseButton.SECONDARY)
		      {
		        HBox g = (HBox) (t.getSource());
		        
		        g.setLayoutX(g.getLayoutX() + offsetX);
		        g.setLayoutY(g.getLayoutY() + offsetY);
		      }
		        orgSceneX = t.getSceneX();
		        orgSceneY = t.getSceneY();
		      });
	    
	    return group;
	}


}
