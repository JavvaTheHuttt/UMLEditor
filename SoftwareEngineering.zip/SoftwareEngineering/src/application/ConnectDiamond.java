package application;


import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;

 class ConnectD extends Line 
{
    public ConnectD(Polygon startBall, Ball endBall) 
    {	
        startXProperty().bind(startBall.layoutXProperty().add(startBall.getBoundsInParent().getWidth() / 3.0));
        startYProperty().bind(startBall.layoutYProperty().add(startBall.getBoundsInParent().getHeight() / 3.0));        
        endXProperty().bind(endBall.centerXProperty());
        endYProperty().bind(endBall.centerYProperty());        
    }
}