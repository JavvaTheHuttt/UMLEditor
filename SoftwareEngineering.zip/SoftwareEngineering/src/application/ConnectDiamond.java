package application;


import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;

 class ConnectD extends Line 
{
	 
	 /***
	  * 
	  * @param startBall (Polygon)
	  * @param endBall (Ball)
	  * This class binds the points of the line to a Polygon
	  * and a Ball and will follow it wherever either Node is dragged.
	  */
	 
    public ConnectD(Polygon startBall, Ball endBall) 
    {
    	startXProperty().bind(startBall.layoutXProperty().add(startBall.getBoundsInParent().getWidth() / 3.0));
        startYProperty().bind(startBall.layoutYProperty().add(startBall.getBoundsInParent().getHeight() / 3.0));        
        endXProperty().bind(endBall.centerXProperty());
        endYProperty().bind(endBall.centerYProperty());        
    }
}