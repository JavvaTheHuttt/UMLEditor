package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

public class textBox 
{
	
	/**
	 * 
	 * @param pane (Pane)
	 * @param frameX (double)
	 * @param frameY (double)
	 * Creates a new button and calls another method to give functionality
	 * @returns newly created Label Button 
	 * 			
	 */

	public Button display(Pane pane, double frameX, double frameY)
	{
		Button box = new Button("Label");
		
		//Button listener to create a new class box
		box.setOnAction(new EventHandler<ActionEvent>()
		{
		       @Override
		       public void handle(ActionEvent e) 
		       {
		    	   	/*
		    	   	 * create new createTextBox and pass doubles' into 
		    	   	 * display method.
		    	   	 * @returns HBox and adds to pane
		    	   	 */
		    	   
		    	   	createTextBox cb = new createTextBox();
					HBox group = (HBox) cb.display(frameX, frameY);
					pane.getChildren().addAll(group);
		       }		 
		});
		
		return box;
	}
}
