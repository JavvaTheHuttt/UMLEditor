package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;

public class CreateETriangle 
{
	
	/*
	 * 
	 * @param pane (Pane)
	 * @param frameX (Double)
	 * @param frameY (Double)
	 * @param string (String)
	 * Creates a new Dependency (dashed line with an empty triangle) or 
	 * Association (line with an empty triangle) that is able to be moved and resized
	 * @returns an a newly created Dependency or Association Button
	 * 			
	 */

	public Button display(Pane pane, Double frameX, Double frameY, String string) 
	{
		Button empty_triangle;
		
		
		if(string == "dash")
		{
			empty_triangle = new Button("Dependency");
		}
		else 
		{
			empty_triangle = new Button("Association");
		}
		
		//Button listener to create a new association or Dependency arrow
		empty_triangle.setOnAction(new EventHandler<ActionEvent>()
		{
			 @Override
		       public void handle(ActionEvent e) 
		       {
				  //creates a triangle using the generic class
		    	  objectMaker<Polygon> q = new objectMaker<Polygon>();
		    	  q.setAttributes("arrow", 25, 25, 5, Color.rgb(204,204,204));
			  	  Polygon t = (Polygon) q.createObject("arrow");
			  	  t.setStrokeWidth(2);
			  	  t.setStroke(Color.BLACK);
		    	  t.relocate(frameX, frameY);
		    	  pane.getChildren().addAll(t);
		    	  
		    	  //creates new Ball by passing frameX, frameY and the radius
		    	  Ball c = new Ball(frameX + 5, frameY + 5, 10);
			  	  c.setFill(Color.TRANSPARENT);
			  	  pane.getChildren().addAll(c);
			  	  
			  	  //create new ConnectD by passing t (Polygon) and c2 (Ball)
			  	  // if creating a Dependency, change the line to be a dashed line
			  	  ConnectD connection = new ConnectD(t, c);
			  	  if(string == "dash")
			  	  	{
			  		  connection.getStrokeDashArray().addAll(25d, 10d);
			  	  	}
			  	  pane.getChildren().addAll(connection);
		       }	 
		});
		
		return empty_triangle;
	}

}
