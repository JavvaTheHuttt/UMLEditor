/*
 * Source Code for Third Iteration
 * Team: Java the Hutt
 * Members: Seth Miller, Dan Sipe, Harry Hawkes and Breanna Caggiano
 * Due: December 8th, 2017
 * Class: Software Engineering: CSCI 420
 * Professor: Dr. David Hutchens
 *  
 */

package application;
	

import javafx.application.Application;
import javafx.stage.Stage;

import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;

import javafx.stage.FileChooser;



public class Main extends Application{
	Circle q;
	static Stage window;
	BorderPane layout;
	double frameX = 800;
	double frameY = 400;
	double orgSceneX, orgSceneY;
	Node temp;
	
	public static void main(String[] args) 
	{
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage)  throws Exception
	{
		try {
			window = primaryStage;
			window.setTitle("UML Editor by Java the Hutt");
			
			//fileChooser for opening, saving, renaming etc the file
			final FileChooser fileChooser = new FileChooser();
			
			//textArea used for saving
		    TextArea textArea = new TextArea();
		    
			/**************************************************************************
			 * 
			 * 		Top Menu
			 * 
			 **************************************************************************/
		    
		    /*
		     * Create new TopMenu
		     * Call display method with the newly created TopMenu 
		     */
		    
		    TopMenu topMenu = new TopMenu();
		    MenuBar menuBar = topMenu.display(window, fileChooser, textArea);
			
		    
			/*********************************************************************************
			 * 
			 * 		Pane
			 * 
			 *********************************************************************************/
		    
		   
		    Pane pane = new Pane();
		    
		    
		    
			/*********************************************************************************
			 *
			 * 		Left Menu
			 * 
			 *********************************************************************************/
			
		    //VBox to store the new buttons
			VBox leftMenu = new VBox(10);
			
			/*
		     * Create new CreateETriangle 
		     * Call display method with the newly created triangle 
		     */
			CreateETriangle t = new CreateETriangle();
			Button empty_triangle = t.display(pane, frameX, frameY, "");
			
			/*
		     * Create new CreateETriangle 
		     * Call display method with the newly created triangle 
		     */
			CreateETriangle s = new CreateETriangle();
			Button dash_empty_triangle = s.display(pane, frameX, frameY, "dash");
			
			/*
		     * Create new CreateFTriangle 
		     * Call display method with the newly created triangle 
		     */
			CreateFTriangle f = new CreateFTriangle();
			Button filled_triangle = f.display(pane, frameX, frameY);
			
			/*
		     * Create new CreateFDiamond 
		     * Call display method with the newly created diamond
		     */
			CreateFDiamond fd = new CreateFDiamond();
			Button diamond = fd.display(pane, frameX, frameY);
			
			/*
		     * Create new CreateEDiamond 
		     * Call display method with the newly created diamond
		     */
			CreateEDiamond ed = new CreateEDiamond();
			Button empty_diamond = ed.display(pane, frameX, frameY);
			
			/*
		     * Create new createCirle 
		     * Call display method with the newly created circle
		     */
			createCircle c = new createCircle();
			Button circle = c.display(pane, frameX, frameY);
			
			/*
		     * Create new CreateLine
		     * Call display method with the newly created line
		     */
			CreateLine l = new CreateLine();
			Button line = l.display(pane, frameX, frameY);
			
			/*
		     * Create new CreateDashedLine 
		     * Call display method with the newly created dashed line
		     */
			CreateDashedLine dl = new CreateDashedLine();
			Button dashed_line = dl.display(pane, frameX, frameY);
	
			/*
		     * Create new createBox 
		     * Call display method with the newly created Class Box
		     */
			createBox b = new createBox();
			Button box = b.display(pane);
			
			/*
		     * Create new textBox 
		     * Call display method with the newly created Label
		     */
			textBox tb = new textBox();
			Button textbox = tb.display(pane, frameX, frameY);
			
			//adds buttons to the VBox
			leftMenu.getChildren().addAll(empty_triangle, dash_empty_triangle, filled_triangle, diamond, empty_diamond, circle, line, dashed_line, box, textbox);
			leftMenu.setId("left_menu");
			
			
			/*********************************************************************************
			 * 
			 * 		Project Layout
			 * 
			 *********************************************************************************/
			
			//adds to the scene
			layout = new BorderPane();
			layout.setTop(menuBar);
			layout.setLeft(leftMenu);
			layout.setCenter(pane);
			

			Scene scene = new Scene(layout,1750,1000);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			window.getIcons().add(new Image("javathehut.jpg"));
			window.setScene(scene);
			window.show();
			
	}
		
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
}
		