
package application;

import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;

public class AlertBox 
{
	 /***
	  * 
	  * @param title (String)
	  * @param header (String)
	  * @param message (String)
	  * This class creates an alert box with the information that was passed into the method
	  * 
	  */

		public void display(String title, String header, String message)
		{
			Alert alert = new Alert(AlertType.INFORMATION);
	        alert.setTitle(title);
	        alert.setHeaderText(header);
	        alert.setContentText(message);
	        alert.show();
		}
	

}
