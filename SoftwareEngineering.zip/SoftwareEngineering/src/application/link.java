package application;

import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;

 class link extends Line
 {

	public link(Circle startBall, Ball endBall) 
	{
		 	startXProperty().bind(startBall.centerXProperty().add(startBall.getBoundsInParent().getWidth() / 3.0));
	        startYProperty().bind(startBall.centerYProperty().add(startBall.getBoundsInParent().getHeight() / 3.0));        
	        endXProperty().bind(endBall.centerXProperty());
	        endYProperty().bind(endBall.centerYProperty()); 
	}

}